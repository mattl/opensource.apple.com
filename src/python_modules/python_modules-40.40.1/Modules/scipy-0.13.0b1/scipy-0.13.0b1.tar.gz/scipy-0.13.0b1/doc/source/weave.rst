======================================
C/C++ integration (:mod:`scipy.weave`)
======================================

.. warning::

   This documentation is work-in-progress and unorganized.

.. automodule:: scipy.weave
   :members:


.. autosummary::
   :toctree: generated/

   inline
   blitz
   ext_tools
   accelerate
