.. include:: ../../HACKING.rst.txt
