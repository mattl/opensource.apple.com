.. automodule:: scipy.integrate
