/* Avoid symbol collisions, just use the real thing */
#include <zconf.h>
